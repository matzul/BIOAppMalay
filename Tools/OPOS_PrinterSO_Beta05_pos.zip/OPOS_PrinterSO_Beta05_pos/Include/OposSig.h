/////////////////////////////////////////////////////////////////////
//
// OposSig.h
//
//   Signature Capture header file for OPOS Applications.
//
// Modification history
// ------------------------------------------------------------------
// 1995-12-08 OPOS Release 1.0                                   CRM
//
/////////////////////////////////////////////////////////////////////

#if !defined(OPOSSIG_H)
#define      OPOSSIG_H


#include "Opos.h"


// No definitions required for this version.


#endif                  // !defined(OPOSSIG_H)
